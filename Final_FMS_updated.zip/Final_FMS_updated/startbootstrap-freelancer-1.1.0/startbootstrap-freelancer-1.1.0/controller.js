/**
 * Created by navsinha on 6/30/2016.
 */
app1.controller("Filmlist",function ($scope,filmService) {




    function categoriesList (category) {
        $scope.categoriesLis1=category;

    };


    function actorList (actor) {
        $scope.actorLis1=actor;

    };
function filmm(film1)
{
    $scope.filmd=film1;
}
    function callback(obj) {
        $scope.films=obj;
        $scope.show=function (film)
        {
            document.getElementById("title").value=film.title;
            document.getElementById("year").value=film.year;
            document.getElementById("language").value=film.language;
            document.getElementById("rating").value=film.rating;
            document.getElementById("description").value=film.description;
            document.getElementById("length").value=film.length;
            categoriesList(film.categories);
            actorList(film.actors);


        }
        $scope.SearchFilmByFilm=function()
        {
            var title= angular.element($('#title')).val();
            console.log(title);
            for(var i=0;i<obj.length;i++)
            {
                if(obj[i].title==title)
                {
                    filmm(obj[i]);
                }
            }
        }
        $scope.SearchFilmByActor=function()
        {
            var firstName= angular.element($('#fname')).val();
            var lastName= angular.element($('#lname')).val();
            console.log(firstName);console.log(lastName);

            var k=0
            for(var i=0;i<obj.length;i++)
            {
                for(var j=0;j<obj[i].actors.length;j++)
                {

                    console.log(obj[i].actors[j]);
                if(obj[i].actors[j].fname==firstName && obj[i].actors[j].lname==lastName)
                {
                    $scope.filmArray[k]=obj[i];
                    k++;
                }
                }
            }
            console.log(filmArray);
            filmm(filmArray);
        }

    }


    filmService(callback);


});
