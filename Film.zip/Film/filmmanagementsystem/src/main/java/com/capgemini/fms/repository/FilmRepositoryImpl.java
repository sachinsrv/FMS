package com.capgemini.fms.repository;

import java.util.Date;
import java.util.List;

import com.capgemini.fms.pojo.Film;

public class FilmRepositoryImpl implements IFilmRepository{

	public Film save(Film film) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Film> searchFilmByTitle(String title) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Film> searchFilmByLanguage(String language) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Film> searchFilmByRating(byte rating) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Film> searchFilmByReleaseYear(Date releaseyear) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean remove(String title) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updateFilm(Film film) {
		// TODO Auto-generated method stub
		return false;
	}

}
